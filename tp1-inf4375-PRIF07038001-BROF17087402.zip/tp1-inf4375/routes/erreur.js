exports.erreur = function(req, res){
	res.render('erreur');
};